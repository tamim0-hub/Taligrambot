
import logging, os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID"))

broker = None
market = None
bot_active = False

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != OWNER_ID:
        await update.message.reply_text("Sorry, this bot is private.")
        return
    await update.message.reply_text("Bot is ready. Use /setbroker, /set, /on, /off")

async def set_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global broker
    if update.effective_user.id != OWNER_ID:
        return
    if not context.args:
        await update.message.reply_text("Usage: /setbroker <quotex|pocket|iqoption>")
        return
    broker = context.args[0].lower()
    await update.message.reply_text(f"Broker set to {broker}")

async def set_market(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global market
    if update.effective_user.id != OWNER_ID:
        return
    if not context.args:
        await update.message.reply_text("Usage: /set <market>")
        return
    market = context.args[0].upper()
    await update.message.reply_text(f"Market set to {market}")

async def bot_on(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global bot_active
    if update.effective_user.id != OWNER_ID:
        return
    bot_active = True
    await update.message.reply_text("Bot is ON. Signal will be sent every 1 minute (mocked).")

async def bot_off(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global bot_active
    if update.effective_user.id != OWNER_ID:
        return
    bot_active = False
    await update.message.reply_text("Bot is OFF.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setbroker", set_broker))
    app.add_handler(CommandHandler("set", set_market))
    app.add_handler(CommandHandler("on", bot_on))
    app.add_handler(CommandHandler("off", bot_off))
    print("Bot is running...")
    app.run_polling()
